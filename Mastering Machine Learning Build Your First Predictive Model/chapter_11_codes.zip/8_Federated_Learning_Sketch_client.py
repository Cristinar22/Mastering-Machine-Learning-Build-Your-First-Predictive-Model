import flwr as fl
from sklearn.linear_model import LogisticRegression
import joblib
from sklearn.metrics import log_loss

# Assuming X_local, y_local, X_val, y_val are defined
model = LogisticRegression(max_iter=1000)

class HospitalClient(fl.client.NumPyClient):
    def get_parameters(self):
        return [model.coef_]

    def fit(self, params, config):
        model.coef_ = params[0]
        model.fit(X_local, y_local)
        return self.get_parameters(), len(X_local), {}

    def evaluate(self, params, config):
        model.coef_ = params[0]
        loss = log_loss(y_val, model.predict_proba(X_val))
        return loss, len(X_val), {}

fl.client.start_numpy_client("127.0.0.1:8080", client=HospitalClient())

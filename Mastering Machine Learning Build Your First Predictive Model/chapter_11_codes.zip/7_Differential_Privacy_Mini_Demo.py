from diffprivlib.models import LogisticRegression
from sklearn.metrics import roc_auc_score

# Assuming X_train, y_train, X_test, y_test are already defined
dp_clf = LogisticRegression(epsilon=3.0, data_norm=2.0, n_jobs=-1)
dp_clf.fit(X_train, y_train)
print("DP AUC:", roc_auc_score(y_test, dp_clf.predict_proba(X_test)[:,1]))

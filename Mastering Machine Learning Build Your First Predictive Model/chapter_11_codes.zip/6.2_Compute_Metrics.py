from fairlearn.metrics import MetricFrame, selection_rate, false_positive_rate
import pandas as pd

# Assuming X, y, y_pred, and group are already defined as in 6.1
mf = MetricFrame(
    metrics={"SelRate": selection_rate, "FPR": false_positive_rate},
    y_true=y, y_pred=y_pred, sensitive_features=group
)
print(mf.by_group)

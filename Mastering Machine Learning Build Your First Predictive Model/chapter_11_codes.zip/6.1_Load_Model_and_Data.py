import joblib
import pandas as pd
from fairlearn.metrics import MetricFrame, selection_rate, false_positive_rate

pipe = joblib.load("models/lgb_fraud.txt")
X = pd.read_parquet("data/creditcard_with_state.parquet")
y = X.pop("Class")
group = X["cardholder_state"]   # sensitive attribute
y_pred = (pipe.predict_proba(X)[:,1] >= 0.15).astype(int)

from fairlearn.reductions import GridSearch, DemographicParity
from lightgbm import LGBMClassifier

# Assuming best_params, X, y, group are already defined
gs = GridSearch(
    estimator=LGBMClassifier(**best_params),
    constraints=DemographicParity(),
    grid_size=7,
    sensitive_features=group
)
gs.fit(X, y)
pipe_fair = gs.best_estimator_

from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np
import pandas as pd

# assuming pipelines lin_pipe, tree, xgb are defined and fitted
models = {"Linear": lin_pipe, "Tree": tree, "XGB": xgb}
scores = []
for name, mdl in models.items():
    pred = mdl.predict(X_te)
    mae = mean_absolute_error(y_te, pred)
    rmse = np.sqrt(mean_squared_error(y_te, pred))
    scores.append({"model": name, "MAE": mae, "RMSE": rmse})

print(pd.DataFrame(scores).sort_values("MAE"))

#!/bin/bash
wget https://raw.githubusercontent.com/PacktWorkshops/The-Ultimate-ML-Repository/main/used_cars.csv
mkdir -p data && mv used_cars.csv data/

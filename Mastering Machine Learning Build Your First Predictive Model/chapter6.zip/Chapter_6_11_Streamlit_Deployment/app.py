import streamlit as st
import pandas as pd
import joblib
from datetime import datetime

df = pd.read_csv("data/used_cars.csv")
bundle = joblib.load("models/xgb_car.joblib")
model, pre = bundle["model"], bundle["pre"]

st.title("Used-Car Price Estimator")
st.markdown("Fill in details and get an instant price guess.")

year = st.slider("Year", 1995, datetime.now().year, 2016)
mileage = st.number_input("Mileage (km)", 0, 400000, 75000)
state = st.selectbox("State", df["state"].unique().tolist())
make = st.selectbox("Make", sorted(df["make"].unique()))
model_nm = st.selectbox("Model", sorted(df[df["make"]==make]["model"].unique()))

if st.button("Estimate Price"):
    X_new = pd.DataFrame([{
        "year": year,
        "mileage": mileage,
        "state": state,
        "make": make,
        "model": model_nm
    }])
    X_new_trans = pre.transform(X_new)
    pred_price = model.predict(X_new_trans)[0]
    st.success(f"Estimated market price: **${pred_price:,.0f}**")

#!/bin/bash
pip install streamlit

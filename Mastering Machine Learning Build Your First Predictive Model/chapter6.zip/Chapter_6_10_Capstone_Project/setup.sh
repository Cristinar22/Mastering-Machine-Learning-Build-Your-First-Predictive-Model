#!/bin/bash
mkdir -p used_car_price/models
cp data/used_cars.csv used_car_price/data/used_cars.csv

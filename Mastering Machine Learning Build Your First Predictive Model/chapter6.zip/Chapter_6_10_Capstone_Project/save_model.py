from joblib import dump

# assuming xgb and pre are trained
dump({"model": xgb, "pre": pre}, "models/xgb_car.joblib")

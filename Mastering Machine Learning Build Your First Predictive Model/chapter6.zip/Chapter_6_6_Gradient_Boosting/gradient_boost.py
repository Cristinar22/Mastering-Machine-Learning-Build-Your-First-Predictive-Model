from xgboost import XGBRegressor
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
import pandas as pd

df = pd.read_csv("data/used_cars.csv")
num = ["year","mileage"]
cat = ["make","model","state"]
X = df[num + cat]
y = df["price"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

pre = ColumnTransformer([
    ("num", "passthrough", num),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat)
])

xgb = Pipeline([
    ("pre", pre),
    ("reg", XGBRegressor(
        n_estimators=400,
        learning_rate=0.05,
        max_depth=5,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        n_jobs=-1,
        objective="reg:absoluteerror"
    ))
])

# initial fit
xgb.fit(X_tr, y_tr)

# early stopping
xgb.named_steps["reg"].set_params(early_stopping_rounds=30)
xgb.fit(
    X_tr, y_tr,
    reg__eval_set=[(pre.fit_transform(X_te), y_te)],
    reg__verbose=False
)

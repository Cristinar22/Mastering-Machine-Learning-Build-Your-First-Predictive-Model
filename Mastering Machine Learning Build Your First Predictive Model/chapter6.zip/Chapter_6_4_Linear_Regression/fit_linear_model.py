from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
import pandas as pd

df = pd.read_csv("data/used_cars.csv")
num = ["year","mileage"]
cat = ["make","model","state"]

X = df[num + cat]
y = df["price"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

pre = ColumnTransformer([
    ("num", "passthrough", num),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat)
])

lin_pipe = Pipeline([
    ("pre", pre),
    ("reg", LinearRegression())
])

lin_pipe.fit(X_tr, y_tr)

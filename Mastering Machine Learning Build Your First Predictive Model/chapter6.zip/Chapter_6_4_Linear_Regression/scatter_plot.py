import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("data/used_cars.csv")
sns.scatterplot(
    x="mileage", 
    y="price", 
    data=df.sample(3000, random_state=1),
    alpha=0.3
)
plt.show()

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/used_cars.csv")
num = ["year","mileage"]
cat = ["make","model","state"]
X = df[num + cat]
y = df["price"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

pre = ColumnTransformer([
    ("num", "passthrough", num),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat)
])

xgb = Pipeline([
    ("pre", pre),
    ("reg", XGBRegressor())
])
xgb.fit(X_tr, y_tr)
pred = xgb.predict(X_te)
res = y_te - pred

plt.scatter(pred, res, alpha=0.3)
plt.axhline(0, color="red")
plt.xlabel("Predicted")
plt.ylabel("Residual")
plt.show()

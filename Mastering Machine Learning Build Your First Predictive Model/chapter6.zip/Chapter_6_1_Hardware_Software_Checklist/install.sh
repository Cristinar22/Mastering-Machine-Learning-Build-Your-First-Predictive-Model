#!/bin/bash
conda create -n ml_reg python=3.12 -y
conda activate ml_reg
pip install pandas scikit-learn matplotlib seaborn xgboost streamlit joblib

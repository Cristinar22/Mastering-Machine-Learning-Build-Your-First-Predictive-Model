import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# ---- 1. Tiny dataset ----
data = {
    "size_sqft": [650, 785, 1200, 1500, 1850, 2100, 2500, 2750],
    "bedrooms":  [1, 2, 2, 3, 3, 4, 4, 5],
    "price_k":   [120, 155, 220, 260, 310, 350, 390, 450]
}
df = pd.DataFrame(data)

# ---- 2. Split features & label ----
X = df[["size_sqft", "bedrooms"]]
y = df["price_k"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42)

# ---- 3. Train model ----
model = LinearRegression()
model.fit(X_train, y_train)

# ---- 4. Evaluate ----
print("R² on test set:", model.score(X_test, y_test).round(3))
print("Coefficients:", model.coef_.round(1))
print("Intercept:", model.intercept_.round(1))

# ---- 5. Predict a new house ----
my_house = [[2000, 3]]
print("Predicted price (k$):", model.predict(my_house).round(0)[0])

# ---- 6. Bonus plot ----
plt.scatter(df["size_sqft"], df["price_k"])
plt.xlabel("Size (sqft)")
plt.ylabel("Price (k$)")
plt.title("House Prices vs. Size")
plt.show()

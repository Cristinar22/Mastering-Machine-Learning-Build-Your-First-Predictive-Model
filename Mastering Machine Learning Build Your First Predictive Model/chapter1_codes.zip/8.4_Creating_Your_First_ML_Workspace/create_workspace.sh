#!/bin/bash
# Creating Your First ML Workspace (Chapter 1, Section 8.4)

# 1. Create a fresh conda environment
conda create -n ml101 python=3.12 -y
conda activate ml101

# 2. Install core libraries
pip install jupyterlab pandas scikit-learn matplotlib seaborn

# Launch JupyterLab
jupyter lab

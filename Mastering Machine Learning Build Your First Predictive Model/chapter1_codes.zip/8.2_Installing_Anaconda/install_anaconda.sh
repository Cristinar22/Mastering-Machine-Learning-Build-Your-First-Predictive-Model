#!/bin/bash
# Installing Anaconda (Chapter 1, Section 8.2)
# Steps to install Anaconda distribution
# 1. Download the installer for your OS from anaconda.com/products/distribution
# 2. Run the installer and follow prompts
# 3. (Optional) Add to PATH when offered
# Verification:
conda --version  # Expected output: conda 24.x.x

from sklearn.model_selection import learning_curve
import numpy as np
import matplotlib.pyplot as plt

train_sizes, train_scores, val_scores = learning_curve(
    estimator=base_model,
    X=X_train, y=y_train,
    train_sizes=np.linspace(0.1, 1.0, 10),
    scoring="roc_auc",
    n_jobs=-1, cv=3, shuffle=True, random_state=42)

plt.plot(train_sizes, train_scores.mean(axis=1), label="Train")
plt.plot(train_sizes, val_scores.mean(axis=1), label="Validation")
plt.ylabel("AUC")
plt.xlabel("Training rows")
plt.legend()
plt.show()

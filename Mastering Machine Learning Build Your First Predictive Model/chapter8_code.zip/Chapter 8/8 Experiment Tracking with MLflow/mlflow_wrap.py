import mlflow

def mlflow_wrap(fn):
    def inner(**kwargs):
        with mlflow.start_run():
            mlflow.log_params(kwargs)
            score = fn(**kwargs)
            mlflow.log_metric("val_auc", score)
            return score
    return inner

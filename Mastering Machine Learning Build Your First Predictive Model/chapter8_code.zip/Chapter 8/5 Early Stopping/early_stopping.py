import lightgbm as lgb

train_set = lgb.Dataset(X_train, label=y_train)
val_set = lgb.Dataset(X_val, label=y_val)

params = dict(
    objective="binary",
    metric="auc",
    learning_rate=0.05,
    num_leaves=64,
    feature_fraction=0.8,
    scale_pos_weight=580
)

gbm = lgb.train(
    params,
    train_set,
    num_boost_round=5000,
    valid_sets=[val_set],
    valid_names=["val"],
    early_stopping_rounds=200,
    verbose_eval=200
)

print("Best iteration:", gbm.best_iteration)

from sklearn.model_selection import validation_curve
import matplotlib.pyplot as plt

param_range = [50, 100, 200, 400, 800]
train, val = validation_curve(
    LightGBMClassifier(**fixed_params),
    X_train, y_train,
    param_name="n_estimators",
    param_range=param_range,
    cv=3, scoring="roc_auc", n_jobs=-1)

plt.semilogx(param_range, train.mean(axis=1), label="Train")
plt.semilogx(param_range, val.mean(axis=1), label="Validation")
plt.xlabel("n_estimators")
plt.ylabel("AUC")
plt.legend()
plt.show()

#!/bin/bash
conda create -n ml_tune python=3.12 -y
conda activate ml_tune
pip install lightgbm optuna mlflow scikit-learn pandas matplotlib seaborn joblib
# Add graphviz (sudo apt-get install graphviz) if you want tree visualisations.

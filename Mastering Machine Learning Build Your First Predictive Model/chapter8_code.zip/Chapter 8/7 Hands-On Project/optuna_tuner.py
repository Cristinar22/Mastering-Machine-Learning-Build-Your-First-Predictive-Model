import optuna
import lightgbm as lgb
import mlflow

mlflow.set_experiment("fraud_lightgbm")

def objective(trial):
    param = {
        "objective": "binary",
        "metric": "auc",
        "learning_rate": trial.suggest_float("lr", 0.01, 0.3, log=True),
        "num_leaves": trial.suggest_int("leaves", 16, 256, step=16),
        "feature_fraction": trial.suggest_float("feat_frac", 0.6, 1.0),
        "bagging_fraction": trial.suggest_float("bag_frac", 0.6, 1.0),
        "bagging_freq": trial.suggest_int("bag_freq", 1, 10),
        "min_child_samples": trial.suggest_int("min_child", 10, 500),
        "scale_pos_weight": 580,
        "verbosity": -1
    }
    train_set = lgb.Dataset(X_tr, y_tr)
    valid_set = lgb.Dataset(X_val, y_val)
    with mlflow.start_run(nested=True):
        booster = lgb.train(param, train_set, num_boost_round=4000,
                            valid_sets=[valid_set],
                            early_stopping_rounds=200,
                            verbose_eval=False)
        auc = booster.best_score["valid_0"]["auc"]
        mlflow.log_metrics({"auc": auc})
        mlflow.log_params(param)
    return auc

study = optuna.create_study(direction="maximize")
study.optimize(objective, n_trials=60, timeout=3600)

import mlflow
import mlflow.sklearn

mlflow.sklearn.log_model(booster, "lgb_fraud")
booster.save_model("models/lgb_fraud.txt")

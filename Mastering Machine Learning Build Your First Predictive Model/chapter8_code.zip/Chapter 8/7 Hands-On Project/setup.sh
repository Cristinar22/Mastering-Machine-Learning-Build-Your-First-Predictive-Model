#!/bin/bash
# Setup folders
mkdir -p fraud_tuning/data
mkdir -p fraud_tuning/notebooks
mkdir -p fraud_tuning/mlruns
mkdir -p fraud_tuning/models
# Place creditcard.csv into fraud_tuning/data/

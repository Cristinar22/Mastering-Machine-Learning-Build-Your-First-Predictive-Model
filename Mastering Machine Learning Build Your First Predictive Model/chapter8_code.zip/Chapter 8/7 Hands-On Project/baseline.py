from joblib import load
from sklearn.metrics import roc_auc_score

pipe = load("models/logreg_fraud.joblib")
y_prob = pipe.predict_proba(X_test)[:,1]
baseline_auc = roc_auc_score(y_test, y_prob)
print("Baseline AUC:", baseline_auc)

import lightgbm as lgb
from sklearn.metrics import roc_auc_score

best_params = study.best_trial.params
booster = lgb.train(best_params, lgb.Dataset(X_train, y_train),
                    num_boost_round=study.best_trial.user_attrs.get("best_iteration", 200))
y_prob_lgb = booster.predict(X_test, num_iteration=booster.best_iteration)
auc_lgb = roc_auc_score(y_test, y_prob_lgb)
print("LightGBM AUC:", auc_lgb)

# Section 5.3 Variance Inflation Factor (VIF) Check
import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor

X = df[["distance", "air_time", "avg_temp"]]
vif = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
pd.Series(vif, index=X.columns).round(2)
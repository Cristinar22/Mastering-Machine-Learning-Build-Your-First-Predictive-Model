# Section 5.2 Correlation Heat-Map
import seaborn as sns
import matplotlib.pyplot as plt

corr = df[cols].corr(method="spearman")
sns.heatmap(corr, annot=True, vmin=-1, vmax=1, cmap="coolwarm")
plt.show()
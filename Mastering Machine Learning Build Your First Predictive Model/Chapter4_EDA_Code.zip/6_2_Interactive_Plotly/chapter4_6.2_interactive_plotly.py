# Section 6.2 Interactive Tilt with Plotly
import plotly.express as px

fig = px.scatter(df, x="distance", y="dep_delay", color="carrier",
                 hover_data=["flight_number"])
fig.update_layout(title="Delay vs Distance by Carrier")
fig.show()
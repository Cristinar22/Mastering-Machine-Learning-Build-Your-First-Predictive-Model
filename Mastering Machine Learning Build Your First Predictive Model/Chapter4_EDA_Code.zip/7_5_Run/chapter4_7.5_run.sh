# Section 7.5 Run
python app.py
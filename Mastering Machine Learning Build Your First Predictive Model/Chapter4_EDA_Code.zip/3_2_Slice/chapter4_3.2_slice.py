# Section 3.2 Slice
import pandas as pd

# Assuming df is already defined
winter = df[df["month"].isin([12, 1, 2])]
summer = df[df["month"].isin([6, 7, 8])]
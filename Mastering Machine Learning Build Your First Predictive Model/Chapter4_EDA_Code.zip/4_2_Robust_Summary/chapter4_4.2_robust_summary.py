# Section 4.2 Robust Summary Table
def dist_summary(s):
    return {
        "mean": s.mean(),
        "median": s.median(),
        "std": s.std(),
        "skew": s.skew(),
        "p99": s.quantile(0.99)
    }

delay_stats = dist_summary(df["dep_delay"])
for k, v in delay_stats.items():
    print(f"{k:>6}: {v:8.2f}")
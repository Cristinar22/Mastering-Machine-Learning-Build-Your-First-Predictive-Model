# Section 4.3 Spotting Outliers Visually
import seaborn as sns
import matplotlib.pyplot as plt

sns.boxplot(x=df["arr_delay"])
plt.show()
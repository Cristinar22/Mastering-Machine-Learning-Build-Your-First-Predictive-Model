# Section 6.1 Annotating a Static Plot
import seaborn as sns
import matplotlib.pyplot as plt

fig, ax = plt.subplots()
sns.lineplot(x="month", y="dep_delay", data=df, ax=ax)
ax.set_title("Average Departure Delay by Month (2019–2024)")
ax.annotate("COVID dip", xy=(4, -2), xytext=(5, 5),
            arrowprops=dict(arrowstyle="->"))
plt.show()
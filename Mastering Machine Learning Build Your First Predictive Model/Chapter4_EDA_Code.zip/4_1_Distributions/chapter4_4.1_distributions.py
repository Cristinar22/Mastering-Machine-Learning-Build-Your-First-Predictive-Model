# Section 4.1 Single Variable: Departure Delay
import seaborn as sns
import matplotlib.pyplot as plt

sns.histplot(df["dep_delay"], bins=100, kde=True)
plt.xlim(-20, 180)
plt.show()
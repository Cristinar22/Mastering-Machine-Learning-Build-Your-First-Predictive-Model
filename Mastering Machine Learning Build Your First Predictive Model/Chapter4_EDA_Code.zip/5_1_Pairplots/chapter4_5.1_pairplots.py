# Section 5.1 Pair-Plots for Quick Pattern Scans
import seaborn as sns
import matplotlib.pyplot as plt

cols = ["dep_delay", "arr_delay", "air_time", "distance"]
sns.pairplot(df[cols], plot_kws=dict(alpha=0.3, s=10))
plt.show()
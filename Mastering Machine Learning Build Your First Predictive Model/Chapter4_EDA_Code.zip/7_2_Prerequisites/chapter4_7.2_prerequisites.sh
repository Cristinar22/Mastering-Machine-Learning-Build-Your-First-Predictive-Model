# Section 7.2 Prerequisites
pip install dash pandas plotly
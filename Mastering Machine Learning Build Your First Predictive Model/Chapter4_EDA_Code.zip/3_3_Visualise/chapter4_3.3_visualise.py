# Section 3.3 Visualise
import seaborn as sns
import matplotlib.pyplot as plt

sns.boxplot(data=[winter["dep_delay"], summer["dep_delay"]],
            orient="h", palette="Set2")
plt.yticks([0, 1], ["Winter", "Summer"])
plt.show()
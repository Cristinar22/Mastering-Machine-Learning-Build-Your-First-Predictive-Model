# Section 3.4 Quantify

winter_mean = winter["dep_delay"].mean()
summer_mean = summer["dep_delay"].mean()
print(f"Winter avg = {winter_mean:.1f} min   Summer avg = {summer_mean:.1f} min")
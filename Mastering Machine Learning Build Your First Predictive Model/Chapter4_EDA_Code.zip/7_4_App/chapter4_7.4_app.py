# Section 7.4 Core Code (app.py)
import dash
from dash import dcc, html, Input, Output
import plotly.express as px
import pandas as pd

df = pd.read_parquet("data/flight_delays_clean.parquet")
df["season"] = df["month"].map({12: "Winter", 1: "Winter", 2: "Winter",
                                3: "Spring", 4: "Spring", 5: "Spring",
                                6: "Summer", 7: "Summer", 8: "Summer",
                                9: "Autumn", 10: "Autumn", 11: "Autumn"})

app = dash.Dash(__name__)

airport_opts = [{"label": a, "value": a} for a in sorted(df["origin"].unique())]

app.layout = html.Div([
    html.H1("U.S. Flight Delay Explorer"),
    html.Label("Choose Airport:"),
    dcc.Dropdown(id="airport", options=airport_opts, value="ATL"),
    html.Label("Choose Season:"),
    dcc.RadioItems(id="season", options=["Winter", "Spring", "Summer", "Autumn"],
                   value="Summer", inline=True),
    dcc.Graph(id="delay_hist"),
    dcc.Graph(id="trend_line")
])

@app.callback(
    [Output("delay_hist", "figure"),
     Output("trend_line", "figure")],
    [Input("airport", "value"),
     Input("season", "value")]
)
def update_charts(airport, season):
    dff = df.query("origin == @airport and season == @season")
    hist = px.histogram(dff, x="dep_delay", nbins=60,
                        title=f"Departure Delay Distribution – {airport} ({season})")
    trend = (dff.groupby("weekday")["dep_delay"]
                 .mean()
                 .reset_index()
                 .assign(weekday=lambda x: x["weekday"].map(
                     {0: "Mon", 1: "Tue", 2: "Wed", 3: "Thu", 4: "Fri", 5: "Sat", 6: "Sun"})))
    line = px.line(trend, x="weekday", y="dep_delay",
                   title="Average Delay by Day of Week")
    return hist, line

if __name__ == "__main__":
    app.run_server(debug=True)
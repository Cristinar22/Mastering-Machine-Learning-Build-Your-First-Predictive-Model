import pandas as pd
df = pd.read_csv("data/used_cars.csv")
target = "price"
# Columns grouped by type
num_cols  = ["year", "mileage", "engine_size"]
cat_cols  = ["make", "model", "state", "transmission"]
date_cols = ["listing_date"]
text_cols = ["description"]

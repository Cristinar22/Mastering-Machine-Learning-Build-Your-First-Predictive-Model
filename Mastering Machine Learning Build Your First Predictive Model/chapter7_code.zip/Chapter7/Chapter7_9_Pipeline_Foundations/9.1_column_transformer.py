from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

pre = ColumnTransformer([
    ("num", StandardScaler(), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
    ("tgt", ce.TargetEncoder(cols=["model"]), ["model"]),
    ("txt", tfidf, "description")
])
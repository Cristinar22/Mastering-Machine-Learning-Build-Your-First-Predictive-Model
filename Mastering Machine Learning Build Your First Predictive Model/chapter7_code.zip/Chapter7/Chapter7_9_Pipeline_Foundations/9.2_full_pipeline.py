from xgboost import XGBRegressor

pipe = Pipeline([
    ("pre", pre),
    ("reg", XGBRegressor(
        n_estimators=400, max_depth=5,
        learning_rate=0.05, subsample=0.8,
        objective="reg:absoluteerror",
        n_jobs=-1, random_state=42))
])
import category_encoders as ce
tgt = ce.TargetEncoder(cols=["model"])
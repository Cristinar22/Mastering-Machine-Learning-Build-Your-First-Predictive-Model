top10 = df["make"].value_counts().nlargest(10).index
df["make_rare"] = df["make"].where(df["make"].isin(top10), "Other")
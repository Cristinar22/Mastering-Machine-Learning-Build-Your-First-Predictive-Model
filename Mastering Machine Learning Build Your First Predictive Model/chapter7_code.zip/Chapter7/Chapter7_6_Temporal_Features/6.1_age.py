from datetime import datetime
this_year = datetime.now().year
df["age"] = this_year - df["year"]
num_cols.append("age")
import numpy as np
import pandas as pd
df["month"] = pd.to_datetime(df["listing_date"]).dt.month
df["month_sin"] = np.sin(2*np.pi*df["month"]/12)
df["month_cos"] = np.cos(2*np.pi*df["month"]/12)
num_cols += ["month_sin","month_cos"]
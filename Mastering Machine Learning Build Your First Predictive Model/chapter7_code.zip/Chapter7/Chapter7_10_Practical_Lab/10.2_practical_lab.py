from sklearn.model_selection import train_test_split
from joblib import dump
from sklearn.metrics import mean_absolute_error

X = df[num_cols + cat_cols + ["description"]]
y = df[target]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2,
                                          random_state=42, stratify=None)

pipe.fit(X_tr, y_tr)
pred = pipe.predict(X_te)
print("MAE:", mean_absolute_error(y_te, pred))

dump(pipe, "models/price_pipe_v7.joblib")

# Sanity test load
import joblib
pipe_loaded = joblib.load("models/price_pipe_v7.joblib")
sample = X_te.sample(5, random_state=1)
pipe_loaded.predict(sample)
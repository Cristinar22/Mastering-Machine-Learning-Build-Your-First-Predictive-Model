keywords = ["garage-kept","single owner","service records"]
for kw in keywords:
    df[f"has_{kw.replace(' ','_')}"] = df["description"].str.contains(kw, case=False)
    cat_cols.append(f"has_{kw.replace(' ','_')}")
import pandas as pd
bins  = [0, 50000, 100000, 150000, 200000, 400000]
labels = ["0-50k","50-100k","100-150k","150-200k","200k+"]
df["mileage_band"] = pd.cut(df["mileage"], bins=bins, labels=labels)
cat_cols.append("mileage_band")
from sklearn.preprocessing import StandardScaler
num_pipe = Pipeline([("scale", StandardScaler())])
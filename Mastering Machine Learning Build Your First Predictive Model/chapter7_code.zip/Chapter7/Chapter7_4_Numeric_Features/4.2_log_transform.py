import numpy as np
df["log_mileage"] = np.log1p(df["mileage"])
num_cols.append("log_mileage")
#!/bin/bash
# Hardware & Software Checklist Setup
conda create -n ml_fe python=3.12 -y
conda activate ml_fe
pip install pandas scikit-learn category_encoders seaborn matplotlib joblib streamlit

import serial
import pandas as pd
import time

ser = serial.Serial("/dev/ttyUSB0", 9600)
rows = []
for _ in range(100):  # read 100 lines
    line = ser.readline().decode().strip()  # e.g., "2025-05-23T10:14:07,31.6"
    ts, val = line.split(",")
    rows.append({"timestamp": ts, "temp_c": float(val)})
    time.sleep(1)
df_sense = pd.DataFrame(rows)
# Sensors often spew different formats; standardise at ingest (ISO-8601 times, metric units).
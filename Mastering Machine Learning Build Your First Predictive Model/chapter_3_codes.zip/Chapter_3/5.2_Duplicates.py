dupes = df.duplicated(subset=["flight_id", "date"])
df = df[~dupes]
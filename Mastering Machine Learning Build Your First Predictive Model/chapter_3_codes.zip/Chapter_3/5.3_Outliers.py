import seaborn as sns
import matplotlib.pyplot as plt

sns.boxplot(x=df["delay_minutes"])
plt.show()
q_hi = df["delay_minutes"].quantile(0.99)
df.loc[df["delay_minutes"] > q_hi, "delay_minutes"] = q_hi
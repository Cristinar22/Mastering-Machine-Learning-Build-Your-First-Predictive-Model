import requests
import pandas as pd

url = "https://api.open-meteo.com/v1/forecast"
params = {"latitude": 52.52, "longitude": 13.41, "hourly": "temperature_2m"}
resp = requests.get(url, params=params, timeout=30)
json = resp.json()["hourly"]
df_api = pd.DataFrame(json)
# Rule of thumb: Cache API calls to disk (to_json()) while developing—no rate-limit surprises.
from sklearn.feature_extraction.text import TfidfVectorizer

tfidf = TfidfVectorizer(max_features=2000, stop_words="english")
X_text = tfidf.fit_transform(df_reviews["review_body"])
import polars as pl

df_pl = pl.read_csv("flight_delays_raw.csv", parse_dates=True)
df_pl = (
    df_pl
    .with_columns([
        pl.col("fl_date").dt.month().alias("month"),
        pl.col("fl_date").dt.weekday().alias("weekday")
    ])
    .filter(pl.col("cancelled") == 0)
    .with_columns(
        pl.col("dep_delay").clip(-15, 180)
    )
)
df_pl.write_parquet("flight_delays_clean.parquet")
# Benchmark: Polars on 10 million rows often runs 5–10× faster than Pandas.
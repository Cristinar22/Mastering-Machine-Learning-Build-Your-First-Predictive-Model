import pandas as pd

def read_raw(path):
    return pd.read_csv(path, parse_dates=["fl_date"])

def add_date_parts(df):
    df["month"] = df["fl_date"].dt.month
    df["weekday"] = df["fl_date"].dt.dayofweek
    return df

def clean_delays(df):
    df = df[df["cancelled"] == 0]
    df["dep_delay"] = df["dep_delay"].clip(-15, 180)
    return df

def pipeline(path):
    return (read_raw(path)
            .pipe(add_date_parts)
            .pipe(clean_delays))

df_ready = pipeline("flight_delays_raw.csv")
# Rule: Each function = one transformation, pure in/out, easy to unit-test.
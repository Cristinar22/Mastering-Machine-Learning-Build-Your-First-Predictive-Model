from sklearn.preprocessing import OneHotEncoder
import pandas as pd

ohe = OneHotEncoder(sparse=False, handle_unknown="ignore")
encoded = ohe.fit_transform(df[["airline"]])
ohe_cols = ohe.get_feature_names_out(["airline"])
df_ohe = pd.DataFrame(encoded, columns=ohe_cols, index=df.index)
df = pd.concat([df.drop(columns="airline"), df_ohe], axis=1)
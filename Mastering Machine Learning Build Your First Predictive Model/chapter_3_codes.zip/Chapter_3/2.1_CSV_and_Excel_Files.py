import pandas as pd

df = pd.read_csv("sales_2024.csv")
# or for Excel:
df_xls = pd.read_excel("inventory.xlsx", sheet_name="Q1")
# Tip: Use low_memory=False for wide files to avoid mixed-type warnings.
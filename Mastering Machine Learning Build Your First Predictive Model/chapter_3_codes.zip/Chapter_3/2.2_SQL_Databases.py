import sqlalchemy as sa
import pandas as pd

engine = sa.create_engine("postgresql://user:pass@localhost:5432/shop")
query = """
SELECT order_id, created_at, total_value
FROM orders
WHERE created_at >= '2024-01-01'
"""
df_sql = pd.read_sql(query, engine)
# Why bother? SQL pulls only the columns and rows you need—saving RAM and time.
import glob
import pandas as pd

files = glob.glob("data/raw/20*.csv")
df = pd.concat((pd.read_csv(f) for f in files), ignore_index=True)
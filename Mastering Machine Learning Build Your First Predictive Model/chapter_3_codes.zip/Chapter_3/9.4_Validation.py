assert df["dep_delay"].isna().sum() == 0
assert df["dep_delay"].between(-15, 360).all()
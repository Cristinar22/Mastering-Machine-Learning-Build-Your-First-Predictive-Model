# 1. Install Miniconda if you skipped Anaconda earlier
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
bash Miniconda3-latest-*.sh

# 2. Create an env
conda create -n ml_fraud python=3.12 -y
conda activate ml_fraud

# 3. Install core libs
pip install pandas scikit-learn matplotlib seaborn plotly imbalanced-learn joblib
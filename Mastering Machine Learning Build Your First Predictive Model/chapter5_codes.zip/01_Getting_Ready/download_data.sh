wget https://storage.googleapis.com/download.tensorflow.org/data/creditcard.csv
mv creditcard.csv data/
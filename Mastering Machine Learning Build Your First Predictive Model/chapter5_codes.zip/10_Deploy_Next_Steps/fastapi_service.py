from fastapi import FastAPI
import joblib
import numpy as np

bundle = joblib.load("models/fraud_bundle.joblib")
model, thr = bundle["model"], bundle["thr"]

app = FastAPI()

@app.post("/predict")
def predict(payload: dict):
    x = np.array(payload["features"]).reshape(1, -1)
    prob = model.predict_proba(x)[0,1]
    flag = prob >= thr
    return {"fraud": bool(flag), "prob": float(prob)}
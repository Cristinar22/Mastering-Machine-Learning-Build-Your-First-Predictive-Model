import numpy as np
import matplotlib.pyplot as plt

z = np.linspace(-10, 10, 200)
p = 1 / (1 + np.exp(-z))
plt.plot(z, p)
plt.xlabel("score z")
plt.ylabel("probability p")
plt.show()
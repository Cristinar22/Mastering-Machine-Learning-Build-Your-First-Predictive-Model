import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from joblib import load
from sklearn.metrics import precision_recall_curve

# Load data and model
df = pd.read_csv("data/creditcard.csv")
X = df.drop("Class", axis=1)
y = df["Class"]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

pipe = load("models/logreg_fraud.joblib")
y_prob = pipe.predict_proba(X_test)[:,1]

# Compute precision and recall for thresholds
thresholds = np.linspace(0, 1, 200)
recalls, precisions = [], []
for t in thresholds:
    y_pred_t = y_prob >= t
    tp = ((y_test==1) & y_pred_t).sum()
    fn = ((y_test==1) & ~y_pred_t).sum()
    fp = ((y_test==0) & y_pred_t).sum()
    recalls.append(tp / (tp+fn))
    precisions.append(tp / (tp+fp) if (tp+fp) else 0)

plt.plot(thresholds, recalls, label="Recall")
plt.plot(thresholds, precisions, label="Precision")
plt.axhline(0.9, linestyle="--")
plt.legend(); plt.xlabel("Threshold"); plt.show()

df_thr = pd.DataFrame(dict(threshold=thresholds, recall=recalls, precision=precisions))
candidate = df_thr[df_thr["recall"] >= 0.9].sort_values("precision", ascending=False).head(1)
print(candidate)
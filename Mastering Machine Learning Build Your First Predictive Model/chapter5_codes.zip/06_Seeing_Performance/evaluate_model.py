from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import pandas as pd
from joblib import load

# Load data and model
df = pd.read_csv("data/creditcard.csv")
X = df.drop("Class", axis=1)
y = df["Class"]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

pipe = load("models/logreg_fraud.joblib")

y_prob = pipe.predict_proba(X_test)[:,1]
y_pred = (y_prob >= 0.5)

cm = confusion_matrix(y_test, y_pred)
print(cm)
print(classification_report(y_test, y_pred, digits=3))
print("ROC-AUC:", roc_auc_score(y_test, y_prob).round(3))

fpr, tpr, _ = roc_curve(y_test, y_prob)
pr, rc, _ = precision_recall_curve(y_test, y_prob)

plt.figure(); plt.plot(fpr, tpr); plt.xlabel("FPR"); plt.ylabel("TPR"); plt.title("ROC"); plt.show()
plt.figure(); plt.plot(rc, pr); plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title("Precision-Recall"); plt.show()
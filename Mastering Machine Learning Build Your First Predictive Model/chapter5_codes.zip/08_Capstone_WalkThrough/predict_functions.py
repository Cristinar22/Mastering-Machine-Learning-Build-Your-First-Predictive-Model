from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

def predict_fraud_prob(model, X):
    return model.predict_proba(X)[:,1]

def predict_fraud_flag(model, X, thr):
    return predict_fraud_prob(model, X) >= thr
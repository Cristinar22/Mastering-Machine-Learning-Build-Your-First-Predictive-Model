from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
import pandas as pd

# Load data
df = pd.read_csv("data/creditcard.csv")
X = df.drop("Class", axis=1)
y = df["Class"]

# Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

# Scaling
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)

# Logistic Regression with class weights
logreg = LogisticRegression(class_weight="balanced", max_iter=1000, n_jobs=-1)
logreg.fit(X_train_sc, y_train)

# Cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
roc_scores = cross_val_score(logreg, X_train_sc, y_train, cv=cv, scoring="roc_auc", n_jobs=-1)
print("CV ROC-AUC:", roc_scores.mean().round(3))
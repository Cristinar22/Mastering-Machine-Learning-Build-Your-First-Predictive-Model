from sklearn.model_selection import train_test_split
from sklearn.dummy import DummyClassifier

import pandas as pd
df = pd.read_csv("data/creditcard.csv")
X = df.drop("Class", axis=1)
y = df["Class"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

print(y_train.mean(), y_test.mean())   # both ≈ 0.17 %

dum = DummyClassifier(strategy="most_frequent")
dum.fit(X_train, y_train)
print("Baseline recall:",
      (y_test & dum.predict(X_test)).sum() / y_test.sum())
import pandas as pd
df = pd.read_csv("data/creditcard.csv")
print(df.shape)            # (284807, 31)
print(df["Class"].value_counts())
train = df[df["Date"] < "2016-01-01"]
test  = df[df["Date"] >= "2016-01-01"]

X_train = train[["hour", "dayofweek", "month", "lag_24"]]
y_train = train["Consumption"]
X_test  = test[["hour", "dayofweek", "month", "lag_24"]]
y_test  = test["Consumption"]

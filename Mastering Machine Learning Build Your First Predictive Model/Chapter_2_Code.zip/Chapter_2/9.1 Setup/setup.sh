#!/bin/bash
conda activate ml101
pip install pandas scikit-learn matplotlib sea-born

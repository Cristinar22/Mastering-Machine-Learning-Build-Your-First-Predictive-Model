df["hour"]        = df["Date"].dt.hour
df["dayofweek"]   = df["Date"].dt.dayofweek
df["month"]       = df["Date"].dt.month
df["lag_24"]      = df["Consumption"].shift(24)
df = df.dropna()

import pandas as pd
url = "https://raw.githubusercontent.com/plotly/datasets/master/opsd_germany_daily.csv"
df = pd.read_csv(url, parse_dates=["Date"])
df = df[["Date", "Consumption"]].dropna()

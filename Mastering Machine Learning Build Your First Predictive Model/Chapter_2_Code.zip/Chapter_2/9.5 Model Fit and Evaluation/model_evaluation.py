from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_percentage_error

model = GradientBoostingRegressor(random_state=0)
model.fit(X_train, y_train)
preds  = model.predict(X_test)
mape   = mean_absolute_percentage_error(y_test, preds)
print(f"MAPE: {mape:.3%}")   # target < 8 %

# Chapter 2 Code Organization

This zip contains all code snippets from Chapter 2 of the book, organized by subheading.

- 9.1 Setup
  - setup.sh: Bash script to set up environment.

- 9.2 Data Ingest
  - data_ingest.py: Load and preprocess the energy consumption data.

- 9.3 Feature Engineering
  - feature_engineering.py: Create features like hour, day of week, and lag.

- 9.4 Train_Test Split
  - train_test.py: Split data chronologically into training and testing sets.

- 9.5 Model Fit and Evaluation
  - model_evaluation.py: Train a Gradient Boosting model and evaluate with MAPE.

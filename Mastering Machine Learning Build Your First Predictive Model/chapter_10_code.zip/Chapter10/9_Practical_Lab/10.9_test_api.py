import json
import requests

def test_local_prediction():
    payload = {
        "year":2016,
        "mileage":75000,
        "make":"Toyota",
        "model":"Corolla",
        "state":"CA",
        "transmission":"automatic",
        "description":""
    }
    r = requests.post(
        "http://localhost:8080/predict",
        data=json.dumps(payload),
        headers={"Content-Type":"application/json"}
    )
    assert r.status_code == 200
    assert r.json()["price_usd"] > 1000

#!/bin/bash
conda activate ml_reg
pip list --format=freeze > requirements.txt
# Trim large dev-only libs from requirements.txt as needed

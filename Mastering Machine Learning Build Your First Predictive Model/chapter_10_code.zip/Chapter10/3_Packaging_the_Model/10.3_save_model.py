from joblib import dump, load

# Load trained pipeline (from Chapter 7)
pipe = load("models/price_pipe.joblib")

# Save model artifact with semantic tag
dump(pipe, "service/car_price_model_v1.joblib")

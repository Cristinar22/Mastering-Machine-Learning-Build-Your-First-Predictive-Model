from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pandas as pd, joblib

app = FastAPI(title="Car Price API", version="1.0.0")
pipe = joblib.load("service/car_price_model.joblib")

class CarInput(BaseModel):
    year:        int   = Field(..., ge=1990, le=2025)
    mileage:     int   = Field(..., ge=0, le=400000)
    make:        str
    model:       str
    state:       str
    transmission:str
    description: str = ""

@app.post("/predict")
def predict_car_price(car: CarInput):
    try:
        X = pd.DataFrame([car.dict()])
        price = pipe.predict(X)[0]
        return {"price_usd": round(float(price), 2)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/health")
def health():
    return {"status": "ok", "model_version": "1.0.0"}

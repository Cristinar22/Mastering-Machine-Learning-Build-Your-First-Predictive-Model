import shap

# SHAP summary plot
explainer = shap.TreeExplainer(booster)
shap_values = explainer.shap_values(X_sample)  # choose 1,000 rows for speed
shap.summary_plot(shap_values, X_sample)
import shap

# Hands-On "Why This Prediction?"
row = X_test.iloc[[123]]
shap.force_plot(
    explainer.expected_value, 
    explainer.shap_values(row), 
    row
)
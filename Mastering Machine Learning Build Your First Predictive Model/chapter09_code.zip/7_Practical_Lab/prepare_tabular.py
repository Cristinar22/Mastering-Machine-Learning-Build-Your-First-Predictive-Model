import pandas as pd

# Step 1 — Prepare Tabular Set
meta = pd.read_csv("data/pneumonia_meta.csv")
X_meta = meta.drop(columns="target")
y_meta = meta["target"]
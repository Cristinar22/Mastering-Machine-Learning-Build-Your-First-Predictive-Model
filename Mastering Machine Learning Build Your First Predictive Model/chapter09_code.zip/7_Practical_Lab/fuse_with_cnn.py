import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import roc_auc_score

# Fuse with CNN Scores
cnn_scores = np.load("data/cnn_probs.npy")  # p1 for same rows
stack_df = pd.DataFrame({"cnn": cnn_scores, "gbdt": p2})
stacker = LogisticRegressionCV(cv=5, scoring="roc_auc", max_iter=500)
stacker.fit(stack_df, y_meta)
stack_auc = roc_auc_score(y_meta, stacker.predict_proba(stack_df)[:,1])
print("Fused AUC:", stack_auc)
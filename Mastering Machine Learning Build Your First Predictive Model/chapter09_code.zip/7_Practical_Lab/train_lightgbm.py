import lightgbm as lgb, numpy as np

# Train LightGBM
train_set = lgb.Dataset(X_meta, y_meta)
params = dict(
    objective="binary", 
    metric="auc",
    learning_rate=0.03, 
    num_leaves=48,
    feature_fraction=0.9, 
    bagging_fraction=0.8,
    bagging_freq=5, 
    seed=42
)
gbdt = lgb.train(params, train_set, num_boost_round=2000, valid_sets=[train_set], verbose_eval=200)
p2 = gbdt.predict(X_meta)
import shap

# Explain Fusion Decision with SHAP
expl = shap.LinearExplainer(stacker, stack_df, feature_perturbation="interventional")
shap.summary_plot(expl.shap_values(stack_df), stack_df)
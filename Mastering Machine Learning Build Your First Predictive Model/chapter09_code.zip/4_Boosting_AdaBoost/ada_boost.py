from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import roc_auc_score

# Quick AdaBoost Example
ab = AdaBoostClassifier(
    n_estimators=400, 
    learning_rate=0.05, 
    random_state=42
)
ab.fit(X_train, y_train)
print("AdaBoost AUC:", roc_auc_score(y_test, ab.predict_proba(X_test)[:,1]))
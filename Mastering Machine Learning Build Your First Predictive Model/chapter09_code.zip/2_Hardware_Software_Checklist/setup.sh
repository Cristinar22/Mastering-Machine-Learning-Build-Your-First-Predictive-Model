#!/bin/bash
conda create -n ml_ensemble python=3.12 -y
conda activate ml_ensemble
pip install scikit-learn lightgbm xgboost shap optuna pandas matplotlib seaborn
# SHAP needs a C++ compiler (already in conda).

from sklearn.ensemble import StackingClassifier
from sklearn.metrics import roc_auc_score

# Base learners
base_learners = [
    ("rf", rf),
    ("lgb", booster)  # from previous chapter
]
stack = StackingClassifier(
    estimators=base_learners,
    final_estimator=AdaBoostClassifier(),
    n_jobs=-1, 
    passthrough=False
)
stack.fit(X_train, y_train)
print("Stacked AUC:", roc_auc_score(y_test, stack.predict_proba(X_test)[:,1]))